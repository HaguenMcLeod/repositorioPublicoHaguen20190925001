//  #####################################################################
//  npm install node@10.X
//  endereco do servidor no browser -->> http://localhost:3000/
//  subir o servidor -->> node server.js no terminal dentro da 
//  pasta do projeto
//  derrubar o servidor -->> ctrl + c no terminal
//  no console, parar o servidor e digitar npm init para 
//  criar o pacote node com o projeto
//  instalacao do Express -->>  npm install express@4.16.3 --save-exact
//  ATENÇÃO - Apagar a pasta "node_modules" ao enviar o projeto para outra 
//  máquina e solicitar ao node que baixe as dependencias novamente com 
//  o comando no terminal "npm install" 
//  Ferramenta que reinicia o servidor automaticamente quando ocorre alguma alteracao - a 
//  parte "--save-dev" indica que será uma dependencia apenas para desenvolvimento
//  sudo npm install nodemon@1.18.4 --save-dev --save-exact e depois 
//  sudo npm install -g nodemon@1.18.4 --save-exact para setar o nodemon 
//  como modulo global
//  Agora para subir o servidor usar o comando nodemon server.js
//  No arquivo package.json modificar de "start": "node server.js" para
//  "start": "nodemon server.js" para no terminal poder iniciar o servidor 
//  com o comando "npm start"
//  Instalar o modulo Marko para criar templates de 
//  paginas -->>  sudo npm install marko@4.13.4-1 --save-exact
//  Adicionar o arquivo database.js baixado na pasta config do 
//  projeto e digitar no terminal: sudo npm install sqlite3@4.0.2 --save-exact 
//  Para desintalar o sqlite -->> npm uninstall sqlite3
//  Instalar o BodyParser para transmitir dados da pagina para dentro 
//  da aplicacao -->> sudo npm install body-parser@1.18.3 --save-exact
//  #####################################################################


const app = require('./src/config/custom-express');

app.listen(3000, function(){
    console.log('Servidor rodando na porta 3000');
});

// 

// // codigo funcionando em 20190908002 abaixo ############################

// const app = require('./src/config/custom-express');

// app.listen(3000, function(){
//     console.log('Servidor rodando na porta 3000');
// })

// app.get('/', function(req, resp){
//     resp.send(
//         `
//             <html>
//                 <head>
//                     <meta charset="utf-8">
//                 </head>
//                 <body>
//                     <h1> Casa do Código </h1>
//                     <h5> Casa do Código 002 </h5>
//                 </body> 
//             </html>
//         `
//     );
// });    
//     app.get('/livros', function(req, resp){
//         resp.send(
//             `
//                 <html>
//                     <head>
//                         <meta charset="utf-8">
//                     </head>
//                      <body>
//                          <h1> Listagem de Livros </h1>
//                      </body> 
//                  </html>
//             `
//         );

// });

// codigo funcionando em 20190908001 abaixo ############################

// const http = require('http');

// const servidor = http.createServer(function(req, resp){
//     let html = '';
//     if (req.url == '/'){
//     html = `
//         <html>
//             <head>
//                 <meta charset="utf-8">
//             </head>
//             <body>
//                 <h1> Casa do Código </h1>
//                 <h5> Casa do Código 002 </h5>
//             </body> 
//         </html>
//     `;
//     }else if (req.url == '/livros'){
//         html = `
//         <html>
//             <head>
//                 <meta charset="utf-8">
//             </head>
//             <body>
//                 <h1> Listagem de Livros </h1>
//             </body> 
//         </html>
//     `;
//     }
//     resp.end(html);
// });
// servidor.listen(3000);
