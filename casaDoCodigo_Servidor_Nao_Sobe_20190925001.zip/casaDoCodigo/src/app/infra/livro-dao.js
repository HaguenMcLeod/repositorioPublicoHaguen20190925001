class livroDao{
    constructor(db){
        this._db = db;
    }

    
    listaTodosOsTitulos001(callback){
        return new Promise((resolve, reject) => {
            console.log("Entrou na funcao de listagem de livros <<<<<<<<<<<<<<<<<<<<<");
            this._db.all(
                'SELECT * FROM livros',
                (erro, resultados) => {
                    if (erro) return reject("Nao foi possivel listar os livros.");
                        return resolve(resultados);
                }    
            )
        })
    }

    exclusaoDeRegistros001(livro){
        return new Promise((resolve, reject) => {
            console.log("001 - Entrou na funcao de exclusao de registros <<<<<<<<<<<<<<<<<<<<<");
            console.log("002 - Variavel carregada corretamente na listagem para exclusao  ---->>>> " + [ livro.titulo ] );
            this._db.all(

                "DELETE FROM livros WHERE titulo = ?",  [ livro.titulo ],

                (erro, resultados) => {
                    if (erro) return reject("Nao foi possivel listar os livros.");
                        return resolve(console.log("Título " + [ livro.titulo ] +  " excluido com sucesso."))
                }   

            )
        })
    }

    listaResultadoBuscaPorTitulo001(livro){

        return new Promise((resolve, reject) => {
            console.log("001 - Entrou na funcao de listagem de livros da busca <<<<<<<<<<<<<<<<<<<<<");
            console.log("002 - Variavel carregada corretamente na listagem da busca  ---->>>> " + [ livro.titulo ] );
            this._db.all(
                "SELECT * FROM livros WHERE titulo = ?",  [ livro.titulo ],
                // valorOriginalDeTitulo = ("SELECT * FROM livros WHERE titulo = ?",  [ livro.titulo ]),
                valorOriginalDeTitulo = livro.titulo ,
                (erro, resultados) => {
                    if (erro) return reject("Nao foi possivel listar os livros.");
                        return resolve(resultados),
                        console.log("001 - Armazenou o valor original do registro -->> " + valorOriginalDeTitulo);
                }    
            )
        })
    }

    adicionaLivroPorTitulo001(livro) {
            return new Promise((resolve, reject) => {
                this._db.run(`
                    INSERT INTO LIVROS (
                            titulo,
                            preco,
                            descricao
                        ) values (?, ?, ?)
                    `,
                    [
                        livro.titulo,
                        livro.preco,
                        livro.descricao
                    ],
                    function (err) {
                        if (err) {
                            console.log(err);
                            return reject('Não foi possível adicionar o livro!');
                        }
                        resolve();
                    } 
                )       
            }
        );
    }

    alteraRegistroPorTitulo001(livro){

        return new Promise((resolve, reject) => {
            console.log("Entrou na funcao de alteracao de livros <<<<<<<<<<<<<<<<<<<<<");
            console.log("Variavel com titulo novo  -------->>>> " + [ livro.novoTitulo ] ),
            console.log("Variavel com titulo original  ---->>>> " + valorOriginalDeTitulo ),
            this._db.get(
                "UPDATE livros SET titulo=? WHERE titulo =? ",  [ livro.novoTitulo , valorOriginalDeTitulo ], 
                (erro, resultados) => {
                    if (erro) return reject("Nao foi possivel listar os livros.");
                        return resolve(resultados);
                }    
            )
        })
    }
}

var valorOriginalDeTitulo = "";
exports.valorOriginalDeTitulo = valorOriginalDeTitulo;
module.exports = livroDao;
