require('marko/node-require').install();
require('marko/express');

const express = require('express');
const app = express();
const bodyParser = require('body-parser');
    app.use(bodyParser.urlencoded({
        // habilita o bodyParser a receber objetos complexos .json
        extended: true
    }));

const rotas = require('../app/rotas/rotas')
rotas(app);

module.exports = app; 
// module.exports = ; 

