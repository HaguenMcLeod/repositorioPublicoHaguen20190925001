import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PucxTituloModule, PucxFormsModule, PucxPanelModule } from '@pucomex-ng-infra/pucx-components';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';



@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    PucxTituloModule,
    PucxFormsModule,
    FormsModule,
    PucxPanelModule,
    ButtonModule,
    ReactiveFormsModule
  ],
  exports: [
    CommonModule,
    PucxTituloModule,
    PucxFormsModule,
    FormsModule,
    PucxPanelModule,
    ButtonModule,
    ReactiveFormsModule
  ]
})
export class CctPrimeModule { }
