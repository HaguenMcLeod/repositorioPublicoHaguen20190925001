import { JsonstringfyPipe } from './jsonstringfy.pipe';

describe('JsonstringfyPipe', () => {
  it('create an instance', () => {
    const pipe = new JsonstringfyPipe();
    expect(pipe).toBeTruthy();
  });
});
