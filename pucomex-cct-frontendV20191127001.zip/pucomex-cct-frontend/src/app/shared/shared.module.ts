import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { JsonstringfyPipe } from './jsonstringfy.pipe';



@NgModule({
  declarations: [JsonstringfyPipe],
  imports: [
    CommonModule

  ],
  exports: [
    JsonstringfyPipe
  ]
})
export class SharedModule { }
