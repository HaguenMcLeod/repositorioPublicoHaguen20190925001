import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ConsultaPreComponent } from './consulta-pre/consulta-pre.component';
import { PucxTituloModule, PucxFormsModule, PucxPanelModule, PucxSelectModule } from '@pucomex-ng-infra/pucx-components';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { CctPrimeModule } from '../cct-prime/cct-prime.module';
import { JsonstringfyPipe } from '../shared/jsonstringfy.pipe';
import { SharedModule } from '../shared/shared.module';


@NgModule({
  declarations: [ConsultaPreComponent],
  imports: [
    CommonModule,
    PucxSelectModule,
    CctPrimeModule,
    // JsonstringfyPipe,
    SharedModule
    ]
})
export class EstoqueModule { }
