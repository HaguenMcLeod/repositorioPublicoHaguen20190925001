import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConsultaPreComponent } from './consulta-pre.component';

describe('ConsultaPreComponent', () => {
  let component: ConsultaPreComponent;
  let fixture: ComponentFixture<ConsultaPreComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConsultaPreComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConsultaPreComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
