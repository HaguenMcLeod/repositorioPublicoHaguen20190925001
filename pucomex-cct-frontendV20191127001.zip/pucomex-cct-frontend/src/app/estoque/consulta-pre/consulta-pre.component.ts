import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { EstoqueService } from '../estoque.service';
import { EstoqueItemNota } from './estoque-item-nota.model';

@Component({
  selector: 'cct-consulta-pre',
  templateUrl: './consulta-pre.component.html',
  styleUrls: ['./consulta-pre.component.css']
})
export class ConsultaPreComponent implements OnInit {

  formConsulta: FormGroup;
  listaEstoqueItemNotaFiscal: EstoqueItemNota[];

  constructor(private formBuilder: FormBuilder,
              private estoqueService: EstoqueService ) { }

    consultar() {
      this.estoqueService.consultaNFE(this.formConsulta.value.chaveAcesso)
        .subscribe((listaEstoqueItemNotaFiscal) =>
                            {
            return this.listaEstoqueItemNotaFiscal = listaEstoqueItemNotaFiscal;
          });
    }

  ngOnInit() {
    this.formConsulta = this.formBuilder.group({
      chaveAcesso: this.formBuilder.control('', [Validators.required])
    });
  }
}
