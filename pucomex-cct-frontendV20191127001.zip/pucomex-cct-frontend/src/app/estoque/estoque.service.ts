import { Injectable } from '@angular/core';
// import { HttpClient } from 'selenium-webdriver/http';
import { Observable } from 'rxjs';
import { EstoqueItemNota } from './consulta-pre/estoque-item-nota.model';
import { HttpClient, HttpParams } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class EstoqueService {

  constructor(private http: HttpClient) {
   }
   consultaNFE(chaveAcesso: string): Observable<EstoqueItemNota[]> {
     const parametros: HttpParams = new HttpParams().append('numeroDocumentoNFE', chaveAcesso);
      return this.http.get<EstoqueItemNota[]>('cct/api/deposito-carga/consultar-estoque-antes-acd', {params: parametros});
   }
}
