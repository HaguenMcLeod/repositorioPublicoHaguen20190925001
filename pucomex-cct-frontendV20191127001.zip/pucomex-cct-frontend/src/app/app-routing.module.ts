import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from '@pucomex-ng-infra/pucx-plataforma-client';
import { ConsultaPreComponent } from './estoque/consulta-pre/consulta-pre.component';

const routes: Routes = [
  { path: '', component: HomeComponent },
  // Declarrar rota do componete criado ***************************************
  { path: 'consulta-estoque-antes-acd', component: ConsultaPreComponent}
];



// const routes: Routes = [
//   { path: '', component: HomeComponent }
// ];

// { path: 'produtos', 
//       component: ProdutosHomeComponent,
//       children: [
//           {
//             path: '', 
//             component: ProdutoListComponent
// },

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
