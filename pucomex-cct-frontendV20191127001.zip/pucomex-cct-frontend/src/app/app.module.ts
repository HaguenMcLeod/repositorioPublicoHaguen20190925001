import { BrowserModule } from '@angular/platform-browser';
import { NgModule, LOCALE_ID } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { AppRoutingModule } from './app-routing.module';
// import { AppComponent } from './app.component';
import { LocationStrategy, HashLocationStrategy } from '@angular/common';
import { PucxPlataformaClientModule, LayoutComponent } from '@pucomex-ng-infra/pucx-plataforma-client';
import { ConsultaPreComponent } from './estoque/consulta-pre/consulta-pre.component';
import { EstoqueModule } from './estoque/estoque.module';

@NgModule({
  declarations: [
    // AppComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    PucxPlataformaClientModule.forRoot(),
    AppRoutingModule,
    EstoqueModule
  ],  
  providers: [{ provide: LocationStrategy, useClass: HashLocationStrategy }, { provide: LOCALE_ID, useValue: 'pt-BR' }],
  bootstrap: [LayoutComponent]
})
export class AppModule { } 
