// sessao.autenticacao.js #####################################################

const uuid = require('uuid/v4');
const sessao = require('express-session');
const passport = require('passport');
const LocalStrategy = require('passport-local').Strategy;

const UsuarioDao = require('../app/infra/usuario-dao');
const db = require('./database');

module.exports = (app) => {

    // configuração da sessão e da autenticação.
    passport.use(new LocalStrategy(
        {
            usernameField: 'email',
            passwordField: 'senha'
        },
        // Função que efetua o login com os dados obtidos acima ###############
        (email, senha, done) => {
            const usuarioDao = new UsuarioDao(db);
            usuarioDao.buscaPorEmail(email)
                        .then(usuario => {
                            if (!usuario || senha != usuario.senha) {
                                return done(null, false, {
                                    mensagem: 'Login e senha incorretos!'
                                });
                            }
                            // Primeiro parâmetro de return é null se #########
                            // não ocorrer nenhum erro ########################
                            return done(null, usuario);
                        })
                        .catch(erro => done(erro, false));
        }
    ));

    // Serialização na autenticação ###########################################
    passport.serializeUser((usuario, done) => {
        const usuarioSessao = {
            // Dados vêm do banco de dados ####################################
            nome: usuario.nome_completo,
            email: usuario.email
        };

        done(null, usuarioSessao);
    });
    
    // Deserialização do usuário ##############################################
    passport.deserializeUser((usuarioSessao, done) => {
        done(null, usuarioSessao);
    });

    // Configuração da sessão #################################################    
    app.use(sessao({
        // Senha "mocada" aqui ################################################ 
        secret: 'node alura',
        // genid -> Retorna uuid -> strings aleatórias ########################
        // para identificar cada usuário ###################################### 
        genid: function(req) {
            return uuid();
        },
        // Não salva nada ao final da sessão ##################################
        resave: false,
        // saveUninitialized -> A sessão só é criada após efetivação do #######
        // login e não para ###################################################
        // qualquer um que acessar a página inicial ###########################
        saveUninitialized: false
    }));

    app.use(passport.initialize());
    app.use(passport.session());

    //  Injeção de dependência - instancia o objeto passaport #################
    app.use(function (req, resp, next) {
        req.passport = passport;
        next();
    });
};