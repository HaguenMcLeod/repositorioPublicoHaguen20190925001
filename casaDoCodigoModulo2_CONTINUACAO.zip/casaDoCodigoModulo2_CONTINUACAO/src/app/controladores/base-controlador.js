// base-controlador.js ########################################################

const templates = require('../views/templates');

class BaseControlador {

    static rotas() {
        return {
            home: '/',
            login: '/login' // nova URL de rota adicionada.
        };
    }

    home() {
        return function(req, resp) {
            resp.marko(
                templates.base.home
            );
        };
    }

    login() {

        return function(req, resp) {
            comsole.log("004 - deu erro ############################");
            resp.marko(templates.base.login);
        };
    }

    // src/app/controladores/base-controlador.js ##############################

    // const LivroControlador = require('./livro-controlador');

    efetuaLogin() {

        return function(req, resp, next) {

            // Lógica de login.
            const passport = req.passport;
            // authenticate -> Executa a estratégia de autenticação ###########
            // A estratégia escolhida foi "local" #############################
            passport.authenticate('local', (erro, usuario, info) => {
                // info -> Não deu erro porém senha e/ou ######################
                // usuário não passaram #######################################
                if (info) {
                    return resp.marko(templates.base.login);
                }

                if (erro) {
                    comsole.log("001 - deu erro ############################");
                    return next(erro);
                }
                // Se não deu erro e usuário e senha passaram #################
                // busca os dados de usuario ##################################
                req.login(usuario, (erro) => {
                    if (erro) {
                        return next(erro);
                        // comsole.log("002 - deu erro ############################");
                    }
                    // Se login deu certo vá para a página com a listagem #####
                    comsole.log("003 - deu erro ############################");
                    return resp.redirect(LivroControlador.rotas().lista);
                });
            // Após o processamento, passa a requisição, a resposta ###########
            // e a função next ################################################   
            })(req, resp, next);
        };
    }
}

module.exports = BaseControlador;