// views/bsae/erros/index.js ##################################################

module.exports = {
    erro404: require('./erros/404.marko'),
    erro500: require('./erros/500.marko'),
    home: require('./home/home.marko'),
    // Adicionada chave para template da pagina de login ######################
    login: require('./login/login.marko')
};