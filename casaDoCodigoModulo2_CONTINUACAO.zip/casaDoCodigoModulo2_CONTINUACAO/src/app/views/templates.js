// views/templates.js ############################################################

module.exports = {
    base: require('./base'),
    livros: require('./livros')
};