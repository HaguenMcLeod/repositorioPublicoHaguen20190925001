import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ImportarCargaComponent } from './importar-carga/importar-carga.component';
import { SharedModule } from '../shared/shared.module';



@NgModule({
  declarations: [ImportarCargaComponent],
  imports: [
    CommonModule,
    // Importar ***************************************************************
    SharedModule
  ],
  exports: [
    // Exportar ***************************************************************
    ImportarCargaComponent
  ]
})
export class ImportacaoModule { }
