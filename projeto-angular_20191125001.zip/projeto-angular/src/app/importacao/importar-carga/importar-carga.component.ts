import { Component, OnInit } from '@angular/core';
import { CodeLabel } from 'src/app/shared/label/code-label.model';

@Component({
  selector: 'app-importar-carga',
  templateUrl: './importar-carga.component.html',
  styleUrls: ['./importar-carga.component.css']
})
export class ImportarCargaComponent implements OnInit {

  item: CodeLabel;

  constructor() { }

  ngOnInit() {
  this.item = new CodeLabel();
  this.item.codigo = 123;
  this.item.label = 'Haguen';
  }
}
