import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ImportarCargaComponent } from './importar-carga.component';

describe('ImportarCargaComponent', () => {
  let component: ImportarCargaComponent;
  let fixture: ComponentFixture<ImportarCargaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ImportarCargaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ImportarCargaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
