export class CodeLabel {
    codigo: number;
    label: string;
}

