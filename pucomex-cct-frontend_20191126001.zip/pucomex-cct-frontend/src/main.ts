import { enableProdMode } from '@angular/core';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

import { AppModule } from './app/app.module';
import { environment } from './environments/environment';
import { Ambiente, PucxAppConfig, Bootstrap } from '@pucomex-ng-infra/pucx-plataforma-client';

if (environment.production) {
  enableProdMode();
}

// SCRIPT DO PLATAFORMA CORE
[
  '/portal/assets/js/jquery.pucx-plataforma.js',
  '/portal/assets/js/angularjs.pucx-plataforma-integration.js'
].forEach(scriptSrc => {
  const script = document.createElement('script');
  script.src = scriptSrc;
  document.querySelector('body').appendChild(script);
});


function bootstrap() {
  platformBrowserDynamic().bootstrapModule(AppModule)
    .catch(err => console.error(err));
}

const ambiente = new Ambiente(environment.appContext, environment.appVersion, environment.buildVersion);
const pucxConfig = new PucxAppConfig(ambiente, bootstrap);

const b = new Bootstrap(pucxConfig);
b.initPortal();

