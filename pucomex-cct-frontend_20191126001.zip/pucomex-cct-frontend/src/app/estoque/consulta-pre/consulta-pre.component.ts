import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'cct-consulta-pre',
  templateUrl: './consulta-pre.component.html',
  styleUrls: ['./consulta-pre.component.css']
})
export class ConsultaPreComponent implements OnInit {

  chaveAcesso: string;

  constructor() { }

  ngOnInit() {
  }

}
