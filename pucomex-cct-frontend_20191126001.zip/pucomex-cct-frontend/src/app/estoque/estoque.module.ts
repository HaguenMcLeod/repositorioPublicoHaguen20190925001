import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ConsultaPreComponent } from './consulta-pre/consulta-pre.component';
import { PucxTituloModule, PucxFormsModule, PucxPanelModule } from '@pucomex-ng-infra/pucx-components';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';

@NgModule({
  declarations: [ConsultaPreComponent],
  imports: [
    CommonModule,
    PucxTituloModule,
    PucxFormsModule,
    FormsModule,
    PucxPanelModule,
    ButtonModule
    ]
})
export class EstoqueModule { }
