export const environment = {
  production: true,
  appContext: '/cct',
  appVersion: 'cct-1.0.0.0.0',
  buildVersion: '001'
};
