import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ConsultaPreComponent } from './consulta-pre/consulta-pre.component';
import { CctPrimeModule } from '../cct-prime/cct-prime.module';

@NgModule({
  declarations: [ConsultaPreComponent],
  imports: [CommonModule, CctPrimeModule]
})
export class EstoqueModule {}
