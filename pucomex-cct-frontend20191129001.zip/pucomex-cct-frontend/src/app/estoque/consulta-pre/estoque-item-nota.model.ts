export class EstoqueItemNota {
  numeroDocumento: string;
  tipo: string;
  numeroNF: number;
  numeroDUE: string;
  dataEmissaoNF: number;
  numeroItem: number;
  codigoNCM: number;
  codigoURF: number;
  codigoRA: number;
  latitude: string;
  longitude: string;
  idResponsavel: string;
  nomeResponsavel: string;
  codigoPaisDestinatario: number;
  nomePaisDestinatario: string;
  anoDeposito: number;
  sequenciaDeposito: number;
  existeConteiner: string;
}
