import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { EstoqueService } from '../estoque.service';
import { EstoqueItemNota } from './estoque-item-nota.model';
import { GridOptions } from '@pucomex-ng-infra/pucx-components';
import { MsgCenterService } from '@pucomex-ng-infra/pucx-plataforma-client';
import { ActivatedRoute, Router } from '@angular/router';
import { DataFormatadaComponent } from 'src/app/shared/data-formatada/data-formatada.component';
import { analyzeAndValidateNgModules } from '@angular/compiler';
import { IconeConteinerComponent } from 'src/app/shared/icone-conteiner/icone-conteiner.component';

@Component({
  selector: 'cct-consulta-pre',
  templateUrl: './consulta-pre.component.html',
  styleUrls: ['./consulta-pre.component.css'],
  entryComponents: [DataFormatadaComponent,
                    IconeConteinerComponent]
})
export class ConsultaPreComponent implements OnInit {
  formConsulta: FormGroup;
  optListaEstoque: GridOptions<EstoqueItemNota>;

  constructor(
    private msgCenter: MsgCenterService,
    private formBuilder: FormBuilder,
    private estoqueService: EstoqueService,
    private rotaAtiva: ActivatedRoute,
    private rota: Router
  ) {}

  consultar() {
    this.rota.navigate(['consulta-estoque-antes-acd'], {
      queryParams: {
        chaveAcesso: this.formConsulta.value.chaveAcesso
      }
    });
  }

  limpar() {
    this.msgCenter.clear();
    this.rota.navigate(['consulta-estoque-antes-acd']);
  }

  reset() {
    this.msgCenter.clear();
    this.formConsulta.reset();
    this.optListaEstoque = this.initOptListaEstoque();
  }

  ngOnInit() {
    this.optListaEstoque = this.initOptListaEstoque();
    this.formConsulta = this.formBuilder.group({
      chaveAcesso: this.formBuilder.control('', [Validators.required])
    });
    this.rotaAtiva.queryParams.subscribe(rotaParams => {
      if (rotaParams.chaveAcesso) {
        this.formConsulta.patchValue({ chaveAcesso: rotaParams.chaveAcesso });
        this.estoqueService
          .consultaNfe(rotaParams.chaveAcesso)
          .subscribe(
            consutaPreRepresentation => (this.optListaEstoque.data = consutaPreRepresentation.lista)
          );
      } else {
        this.reset();
      }
    });
  }

  initOptListaEstoque(): GridOptions<EstoqueItemNota> {
    return {
      cols: [
        { header: 'Nº do documento', field: 'numeroDocumento' },
        { header: 'Data/hora de emissão', field: 'dataEmissaoNF',
            component:
            {
              type: DataFormatadaComponent,
              listener: console.log },
            },
        { header: 'Nº do item', field: 'numeroItem' },
        { header: 'Unidade da RFB', field: 'codigoURF' },
        { header: 'Recinto aduaneiro', field: 'codigoRA' },
        { header: 'Nome do responsável', field: 'nomeResponsavel' },
        { header: 'NCM', field: 'codigoNCM' },
        { header: 'País do destinatário', field: 'nomePaisDestinatario' },

        // { header: 'Contêiner', field: 'existeConteiner' }
        { header: 'Contêiner', field: 'existeConteiner',
          component:
          {
            type: IconeConteinerComponent,
            listener: console.log},
           }
      ],
      data: []
    };
  }
}
