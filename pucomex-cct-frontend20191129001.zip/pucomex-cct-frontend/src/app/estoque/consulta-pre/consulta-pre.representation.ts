import { EstoqueItemNota } from './estoque-item-nota.model';
export class ConsultaPreRepresentation {
  lista: EstoqueItemNota[];
}
