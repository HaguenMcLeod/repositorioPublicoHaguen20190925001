import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { EstoqueItemNota } from './consulta-pre/estoque-item-nota.model';
import { HttpClient, HttpParams } from '@angular/common/http';
import { ConsultaPreRepresentation } from './consulta-pre/consulta-pre.representation';

@Injectable({
  providedIn: 'root'
})
export class EstoqueService {
  constructor(private http: HttpClient) {}

  consultaNfe(chaveAcesso: string): Observable<ConsultaPreRepresentation> {
    const parametros: HttpParams = new HttpParams().append('numeroDocumentoNFE', chaveAcesso);

    return this.http.get<ConsultaPreRepresentation>(
      'cct/api/deposito-carga/consultar-estoque-antes-acd',
      {
        params: parametros
      }
    );
  }
}
