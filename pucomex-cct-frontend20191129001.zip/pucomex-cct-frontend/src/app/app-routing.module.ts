import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from '@pucomex-ng-infra/pucx-plataforma-client';
import { ConsultaPreComponent } from './estoque/consulta-pre/consulta-pre.component';

const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'consulta-estoque-antes-acd', component: ConsultaPreComponent },
  { path: 'consulta-estoque-antes-acd/:id', component: HomeComponent },
  { path: 'recepcao', 
      loadChildren: './recepcao/recepcao.module#RecepcaoModule' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {}
