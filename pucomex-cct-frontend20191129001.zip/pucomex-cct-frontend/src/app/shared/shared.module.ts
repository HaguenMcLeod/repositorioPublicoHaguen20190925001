import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { JsonstringfyPipe } from './jsonstringfy.pipe';
import { DataFormatadaComponent } from './data-formatada/data-formatada.component';
import { IconeConteinerComponent } from './icone-conteiner/icone-conteiner.component';



@NgModule({
  declarations: [JsonstringfyPipe, DataFormatadaComponent, IconeConteinerComponent],
  imports: [
    CommonModule
  ],
  exports: [JsonstringfyPipe,
    DataFormatadaComponent,
    IconeConteinerComponent]
})
export class SharedModule { }
