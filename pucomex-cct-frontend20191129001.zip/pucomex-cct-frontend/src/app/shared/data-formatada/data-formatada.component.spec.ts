import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DataFormatadaComponent } from './data-formatada.component';

describe('DataFormatadaComponent', () => {
  let component: DataFormatadaComponent;
  let fixture: ComponentFixture<DataFormatadaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DataFormatadaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DataFormatadaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
