import { Component, OnInit, Input, Output, EventEmitter, PipeTransform } from '@angular/core';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'cct-data-formatada',
  templateUrl: './data-formatada.component.html',
  styleUrls: ['./data-formatada.component.css']
})
export class DataFormatadaComponent implements OnInit {

  @Output()
    onEvent: EventEmitter<any> = new EventEmitter();

  @Input()
    cow;
  
  constructor() { }

  formatarData(): string {
    const pipeDate = new DatePipe('en');
    return pipeDate.transform(new Date(this.row.dataEmissaoNF),
    'dd/MM/yyyy');
  }

  ngOnInit() {
  }
}
