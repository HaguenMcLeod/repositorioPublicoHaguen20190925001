import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IconeConteinerComponent } from './icone-conteiner.component';

describe('IconeConteinerComponent', () => {
  let component: IconeConteinerComponent;
  let fixture: ComponentFixture<IconeConteinerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IconeConteinerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IconeConteinerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
