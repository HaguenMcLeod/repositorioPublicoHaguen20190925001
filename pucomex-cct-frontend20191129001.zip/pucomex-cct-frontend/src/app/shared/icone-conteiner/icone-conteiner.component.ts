import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'cct-icone-conteiner',
  templateUrl: './icone-conteiner.component.html',
  styleUrls: ['./icone-conteiner.component.css']
})
export class IconeConteinerComponent implements OnInit {

  // @Output()
  // onEvent: EventEmitter<any> = new EventEmitter();

  constructor() { }

  formatarData(): string {
    const pipeDate = new DatePipe('en');
    return pipeDate.transform(new Date(this.row.dataEmissaoNF),
    'dd/MM/yyyy');
  }

  ngOnInit() {
  }

}
