import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  PucxTituloModule,
  PucxFormsModule,
  PucxPanelModule,
  PucxGridModule
} from '@pucomex-ng-infra/pucx-components';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { SharedModule } from '../shared/shared.module';

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    PucxTituloModule,
    PucxFormsModule,
    FormsModule,
    ReactiveFormsModule,
    PucxPanelModule,
    ButtonModule,
    SharedModule,
    PucxGridModule
  ],
  exports: [
    PucxGridModule,
    PucxTituloModule,
    PucxFormsModule,
    FormsModule,
    PucxPanelModule,
    ButtonModule,
    SharedModule,
    ReactiveFormsModule
  ]
})
export class CctPrimeModule {}
