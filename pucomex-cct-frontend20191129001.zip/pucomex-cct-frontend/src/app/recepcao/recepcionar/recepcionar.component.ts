import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'cct-recepcionar',
  templateUrl: './recepcionar.component.html',
  styleUrls: ['./recepcionar.component.css']
})
export class RecepcionarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
