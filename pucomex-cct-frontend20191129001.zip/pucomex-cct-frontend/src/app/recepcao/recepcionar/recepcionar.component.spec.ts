import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RecepcionarComponent } from './recepcionar.component';

describe('RecepcionarComponent', () => {
  let component: RecepcionarComponent;
  let fixture: ComponentFixture<RecepcionarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RecepcionarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RecepcionarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
