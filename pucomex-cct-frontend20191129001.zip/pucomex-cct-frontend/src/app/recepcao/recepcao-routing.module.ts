import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ListarComponent } from './listar/listar.component';
import { RecepcionarComponent } from './recepcionar/recepcionar.component';
import { CancelarComponent } from './cancelar/cancelar.component';

const routes: Routes = [
  { path: '', redirectTo: 'listar'},
  { path: 'listar', component: ListarComponent },
  { path: 'recepcionar', component: RecepcionarComponent },
  { path: 'cancelar', component: CancelarComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class RecepcaoRoutingModule {}
