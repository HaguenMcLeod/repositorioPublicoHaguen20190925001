import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'cct-listar',
  templateUrl: './listar.component.html',
  styleUrls: ['./listar.component.css']
})
export class ListarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
