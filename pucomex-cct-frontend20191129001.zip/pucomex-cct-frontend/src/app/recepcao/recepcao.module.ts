import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { RecepcaoRoutingModule } from './recepcao-routing.module';
import { ListarComponent } from './listar/listar.component';
import { RecepcionarComponent } from './recepcionar/recepcionar.component';
import { CancelarComponent } from './cancelar/cancelar.component';


@NgModule({
  declarations: [ListarComponent, RecepcionarComponent, CancelarComponent],
  imports: [
    CommonModule,
    RecepcaoRoutingModule
  ]
})
export class RecepcaoModule { }
