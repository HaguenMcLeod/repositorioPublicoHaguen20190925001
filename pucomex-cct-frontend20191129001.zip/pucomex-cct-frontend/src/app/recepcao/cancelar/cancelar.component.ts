import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'cct-cancelar',
  templateUrl: './cancelar.component.html',
  styleUrls: ['./cancelar.component.css']
})
export class CancelarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
