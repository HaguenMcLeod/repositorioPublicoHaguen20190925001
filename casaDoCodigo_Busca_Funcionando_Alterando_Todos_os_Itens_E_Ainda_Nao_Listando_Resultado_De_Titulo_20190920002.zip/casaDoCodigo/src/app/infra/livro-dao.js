class livroDao{
    constructor(db){
        this._db = db;
    }
    
    listaTodosOsTitulos001(callback){
        return new Promise((resolve, reject) => {
            console.log("Entrou na funcao de listagem de livros <<<<<<<<<<<<<<<<<<<<<");
            this._db.all(
                'SELECT * FROM livros',
                (erro, resultados) => {
                    if (erro) return reject("Nao foi possivel listar os livros.");
                        return resolve(resultados);
                }    
            )
        })
    }

    listaResultadoBuscaPorTitulo001(livro){
        return new Promise((resolve, reject) => {
            console.log("Entrou na funcao de listagem de livros da busca <<<<<<<<<<<<<<<<<<<<<");
            console.log("Variavel carregada corretamente na listagem da busca  ---->>>> " + [ livro.titulo ] );
            this._db.all(
                "SELECT * FROM livros WHERE titulo = ?",  [ livro.titulo ],
                (erro, resultados) => {
                    if (erro) return reject("Nao foi possivel listar os livros.");
                        return resolve(resultados);
                }    
            )
        })
    }

    adicionaLivroPorTitulo001(livro) {
        return new Promise((resolve, reject) => {
            this._db.run(`
                INSERT INTO LIVROS (
                        titulo,
                        preco,
                        descricao
                    ) values (?, ?, ?)
                `,
                [
                    livro.titulo,
                    livro.preco,
                    livro.descricao
                ],
                function (err) {
                    if (err) {
                        console.log(err);
                        return reject('Não foi possível adicionar o livro!');
                    }
                    resolve();
                } 
            )       
        });
    }


    // ##################################################################################
    listaResultadoAlteracaoPorTitulo001(livro){
        return new Promise((resolve, reject) => {
            console.log("Entrou na funcao de alteracao de livros <<<<<<<<<<<<<<<<<<<<<");
            console.log("Variavel com titulo original  ---->>>> " + [ livro.titulo ] );
            console.log("Variavel com titulo novo  ---->>>> " + [ livro.novoTitulo ] );

            this._db.all(

                // "UPDATE customers SET address = 'Canyon 123' WHERE address = 'Valley 345'"",

                // "UPDATE livros SET titulo = ?",  [ livro.titulo ],
                // ESSA QUERY ATUALIZA TODOS OS REGISTROS ###################################
                "UPDATE livros SET titulo = ?",  [ livro.novoTitulo ],

                // "UPDATE livros SET titulo=? WHERE titulo =123k ",  [ livro.novoTitulo ],

                // UPDATE stores SET openingTime=?, closingHours=?, phon

                // "SELECT * FROM livros WHERE titulo = ?",  [ livro.titulo ],
                (erro, resultados) => {
                    if (erro) return reject("Nao foi possivel listar os livros.");
                        return resolve(resultados);
                }    
            )
        })
    }
}

module.exports = livroDao;