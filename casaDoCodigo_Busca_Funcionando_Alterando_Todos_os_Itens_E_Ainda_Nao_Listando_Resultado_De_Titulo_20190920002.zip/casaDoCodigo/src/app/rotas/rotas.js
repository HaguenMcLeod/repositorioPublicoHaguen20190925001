const LivroDao = require('../infra/livro-dao');
const db = require('../../config/database');

module.exports = (app) => {
    app.get('/livros/manutencaoLivros/inclusaoLivros', function(req, resp){    
        console.log("Entrou no primeiro get da inclusao de livros <<<<<<<<<<<<<<<<<<<<");
        resp.marko(require('../views/livros/manutencaoLivros/inclusaoLivros/form'));
    });

    app.post('/livros/manutencaoLivros/inclusaoLivros', function(req, resp) {    
        console.log("Entrou no primeiro post da inclusao de livros <<<<<<<<<<<<<<<<<<<<");
        const livroDao = new LivroDao(db);
        livroDao.adicionaLivroPorTitulo001(req.body)
        .then(resp.redirect('/livros/manutencaoLivros/inclusaoLivros/lista'))
                .catch(erro => console.log(erro)); 
    });

    app.get('/livros/manutencaoLivros/inclusaoLivros/lista', function(req, resp){ 
        console.log("Entrou no segundo get da inclusao de livros <<<<<<<<<<<<<<<<<<<<");
        const livroDao = new LivroDao(db);
        livroDao.listaTodosOsTitulos001()
                .then(livros => resp.marko(
                    require('../views/livros/manutencaoLivros/inclusaoLivros/lista.marko'),
                    {
                        livros: livros 
                    }
                )      
            )
            .catch(erro => console.log(erro));  
    });

    app.get('/livros/manutencaoLivros/buscaLivros', function(req, resp){    
        console.log("Entrou no primeiro get da busca de livros <<<<<<<<<<<<<<<<<<<<");
        resp.marko(require('../views/livros/manutencaoLivros/buscaLivros/buscaPorTitulo'));
    });

    app.post('/livros/manutencaoLivros/buscaLivros', function(req, resp) {    
        console.log("Entrou no primeiro post busca de livros <<<<<<<<<<<<<<<<<<<<");
        
        const livroDao = new LivroDao(db);
        livroDao.listaResultadoBuscaPorTitulo001(req.body)
                .then(livros => resp.marko(
                    require('../views/livros/manutencaoLivros/buscaLivros/resultadoBuscaPorTitulo.marko'),
                    {
                        livros: livros 
                    }
                )      
            )
            .catch(erro => console.log(erro)); 
    });

    // ################################################################
    app.get('/livros/manutencaoLivros/alteracaoLivros', function(req, resp){    
        console.log("Entrou no primeiro get da alteracao de livros <<<<<<<<<<<<<<<<<<<<");
        resp.marko(require('../views/livros/manutencaoLivros/alteracaoLivros/alteracaoPorTitulo'));
    });

    app.get('/livros/manutencaoLivros/alteracaoLivros', function(req, resp){    
    console.log("Entrou no resultado da busca para alteracao <<<<<<<<<<<<<<<<<<<<");
    resp.marko(require('../views/livros/manutencaoLivros/alteracaoLivros/resultadoBuscaAlteracaoPorTitulo'));
    });

    app.post('/livros/manutencaoLivros/alteracaoLivros', function(req, resp) {    
        console.log("Entrou no primeiro post alteracao de livros <<<<<<<<<<<<<<<<<<<<");
        
        const livroDao = new LivroDao(db);
        livroDao.listaResultadoBuscaPorTitulo001(req.body)
                .then(livros => resp.marko(
                    require('../views/livros/manutencaoLivros/alteracaoLivros/resultadoBuscaAlteracaoPorTitulo.marko'),
                    {
                        livros: livros 
                    }
                )      
            )
            .catch(erro => console.log(erro)); 
    });

    app.post('/livros/manutencaoLivros/alteracaoLivros/resultadoAlteracaoPorTitulo', function(req, resp) {    
        console.log("Entrou no segundo post alteracao de livros <<<<<<<<<<<<<<<<<<<<");
        
        const livroDao = new LivroDao(db);
        livroDao.listaResultadoAlteracaoPorTitulo001(req.body)
                .then(livros => resp.marko(
                    require('../views/livros/manutencaoLivros/alteracaoLivros/resultadoAlteracaoPorTitulo.marko'),
                    {
                        livros: livros 
                    }
                )      
            )
            .catch(erro => console.log(erro)); 
    });

    // app.get('/livros/manutencaoLivros/alteracaoLivros', function(req, resp){    
    //     console.log("Entrou no segundo get da alteracao de livros <<<<<<<<<<<<<<<<<<<<");
    //     resp.marko(require('../views/livros/manutencaoLivros/alteracaoLivros/resultadoAlteracaoPorTitulo'));
    // });

};