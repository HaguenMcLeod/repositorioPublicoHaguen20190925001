//  #####################################################################
//  0 - sudo apt-get install -y nodejs
//  1 - npm install node@10.X
//  2 - endereco do servidor no browser -->> http://localhost:3000/
//  3 - subir o servidor -->> node server.js no terminal dentro da 
//  pasta do projeto
//  4 - derrubar o servidor -->> ctrl + c no terminal
//  5 - no console, parar o servidor e digitar npm init para 
//  criar o pacote node com o projeto
//  6 - instalacao do Express -->>  npm install express@4.16.3 --save-exact
//  ATENÇÃO - Apagar a pasta "node_modules" ao enviar o projeto para outra 
//  máquina e solicitar ao node que baixe as dependencias novamente com 
//  o comando no terminal "npm install" 
//  7 - Ferramenta que reinicia o servidor automaticamente quando ocorre alguma alteracao - a 
//  parte "--save-dev" indica que será uma dependencia apenas para desenvolvimento
//  sudo npm install nodemon@1.18.4 --save-dev --save-exact e depois 
//  sudo npm install -g nodemon@1.18.4 --save-exact para setar o nodemon 
//  como modulo global
//  8 - Agora para subir o servidor usar o comando nodemon server.js
//  9 - No arquivo package.json modificar de "start": "node server.js" para
//  "start": "nodemon server.js" para no terminal poder iniciar o servidor 
//  com o comando "npm start"
//  10 - Instalar o modulo Marko para criar templates de 
//  paginas -->>  sudo npm install marko@4.13.4-1 --save-exact
//  11 - Adicionar o arquivo database.js baixado na pasta config do 
//  projeto e digitar no terminal: sudo npm install sqlite3@4.0.2 --save-exact 
//  12 - Para desintalar o sqlite -->> npm uninstall sqlite3
//  13 - Instalar o BodyParser para transmitir dados da pagina para dentro 
//  da aplicacao -->> sudo npm install body-parser@1.18.3 --save-exact
//  14 - Instalar pacote para sobrescrita de 
//  codigo HTML -->> npm install method-override@3.0.0 --save-exact e instanciar 
//  DEPOIS do BodyParser
//  #####################################################################

const app = require('./src/config/custom-express');

app.listen(3000, function() {
    console.log(`Servidor rodando na porta 3000`);
});
