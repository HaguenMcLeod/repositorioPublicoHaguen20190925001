const { check, validationResult } = require('express-validator/check');
const LivroDao = require('../infra/livro-dao');
const db = require('../../config/database');
// const LivroControlador = require('../controladores/livro-controlador');
const LivroControlador = require('../controladores/livro-controlador');
const livroControlador = new LivroControlador();

module.exports = (app) => {
    app.get('/', function(req, resp) {
        resp.marko(
            require('../views/base/home/home.marko')
        );
    });

    app.get('/livros', livroControlador.lista());

    // app.get('/livros', function(req, resp) {
    //     console.log('002 - Entrou no get da listagem de livros ########################');
    //         livroControlador.lista();
    // });

    // app.get('/livros', function(req, resp) {
    //     console.log('003 - Entrou no controlador da listagem de livros ########################');
    //     const livroDao = new LivroDao(db);
    //     console.log('004 - #################################################'),
    //     livroDao.lista()
    //                 .then(livros => resp.marko(
    //                 console.log('005 - #################################################'),
    //                 require('../views/livros/lista/lista.marko'),
    //                 {
    //                     livros: livros
    //                 }
    //             ))
    //             .catch(erro => console.log(erro));
    // });



















    app.get('/livros/form', function(req, resp) {
        console.log('001 - Entrou no get da inclusao de livros ########################');
        resp.marko(require('../views/livros/form/form.marko'), { livro: {} });
    });

    app.get('/livros/form/:id', function(req, resp) {
        const id = req.params.id;
        const livroDao = new LivroDao(db);

        livroDao.buscaPorId(id)
                .then(livro => 
                    resp.marko(
                        require('../views/livros/form/form.marko'), 
                        { livro: livro }
                    )
                )
                .catch(erro => console.log(erro));
    });

    // Validação de campos ################################################
    // Exibição de msg de erro na tela da aplicacao #######################
    // npm install express-validator@5.3.1 --save-exact
    app.post('/livros', [
        check('titulo').isLength({ min: 5 }).withMessage('O título precisa ter no mínimo 5 caracteres.'),
        check('preco').isCurrency().withMessage('O preço precisa ter um valor.')
    ], function(req, resp) {
        console.log(req.body);
        const livroDao = new LivroDao(db);

        const erros = validationResult(req);

        if (!erros.isEmpty()) {
            return resp.marko(
                require('../views/livros/form/form.marko'),
                { 
                    livro: {},
                    // livro: req.body,
                    errosValidacao: erros.array()
                }
            );
        }

        livroDao.adiciona(req.body)
                .then(resp.redirect('/livros'))
                .catch(erro => console.log(erro));
    });

    // app.post('/livros', function(req, resp) {
    //     console.log(req.body);
    //     const livroDao = new LivroDao(db);
        
    //     livroDao.adiciona(req.body)
    //             .then(resp.redirect('/livros'))
    //             .catch(erro => console.log(erro));
    // });

    app.put('/livros', function(req, resp) {
        console.log(req.body);
        const livroDao = new LivroDao(db);
        
        livroDao.atualiza(req.body)
                .then(resp.redirect('/livros'))
                .catch(erro => console.log(erro));
    });

    app.delete('/livros/:id', function(req, resp) {
        const id = req.params.id;

        const livroDao = new LivroDao(db);
        livroDao.remove(id)
                .then(() => resp.status(200).end())
                .catch(erro => console.log(erro));
    });
};