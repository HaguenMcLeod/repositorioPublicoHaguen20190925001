const LivroDao = require('../infra/livro-dao');
const db = require('../../config/database');

class LivroControlador{

    lista(){
        return function(req, resp) {
            console.log('003 - Entrou no controlador da listagem de livros ########################');

            // const id = req.params.id;

            const livroDao = new LivroDao(db);
            // livroDao.lista(req)
            // livroDao.lista(id)
            // livroDao.lista(req.body)
            // livroDao.lista(req.body)
            livroDao.listaLivros()
            // livroDao.listaLivros(resultados)
            // livroDao.lista(livro.id)
                        .then(livros => resp.marko(
                        console.log('004 - Entrou no metodo para listar os livros apos insercao #########################'),
                        require('../views/livros/lista/lista.marko'),
                        console.log('005 - Chegou ate antes do loop que lista os livros #########################'),
                        {
                            // resultados: resultados
                            livros: livros
                            // Livros: livros
                            // 
                            // { livros: livros }
                        }
                    ))
                    .catch(erro => console.log(erro));
        };
    }
}

module.exports = LivroControlador;