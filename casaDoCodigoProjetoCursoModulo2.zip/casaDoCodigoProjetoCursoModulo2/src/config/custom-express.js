require('marko/node-require').install();
require('marko/express');

const express = require('express');
const app = express();
const bodyParser = require('body-parser');
const methodOverride = require('method-override');

app.use('/estatico', express.static('src/app/public'));

app.use(bodyParser.urlencoded({
    extended: true
}));
app.use(methodOverride(function (req, res) {
    if (req.body && typeof req.body === 'object' && '_method' in req.body) {
      // look in urlencoded POST bodies and delete it
      var method = req.body._method;
      delete req.body._method;
      return method;
    }
}));

// Tratamento de erros -> colocar as paginas com msgs de erro em: 
// home/haguenmcleod/Backup20190927001/CursosInformatica/NodeJs/
// casaDoCodigoProjetoCursoModulo2/src/app/views/base
const rotas = require('../app/rotas/rotas');
rotas(app);

// next informa para aonde o midleware vai apos ser executado ###############
app.use(function(req, resp, next){
    return resp.status(404).marko(
    require('../app/views/base/erros/404.marko')
    );
  }
);

// Parametro ERRO precisa ser declarado ###################################
app.use(function(erro, req, resp, next){
    return resp.status(500).marko(
    require('../app/views/base/erros/500.marko')
    );
  }
);

module.exports = app;